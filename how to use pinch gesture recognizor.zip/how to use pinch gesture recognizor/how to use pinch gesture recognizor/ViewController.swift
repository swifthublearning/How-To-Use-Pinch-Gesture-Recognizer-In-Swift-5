//
//  ViewController.swift
//  how to use pinch gesture recognizor
//
//  Created by Supine Hub Technologies Pvt. Ltd. on 17/03/20.
//  Copyright © 2020 Supine Hub Technologies Pvt. Ltd. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    let imageview = UIImageView()
    let pinchgesture = UIPinchGestureRecognizer()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        imageview.frame = CGRect(x: 0, y: 0, width: 250, height: 250)
        imageview.image = #imageLiteral(resourceName: "Swift Hub Logo")
        imageview.isUserInteractionEnabled = true
        self.view.addSubview(imageview)
        
        imageview.center = view.center
        imageview.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        imageview.centerYAnchor.constraint(equalTo: view.centerYAnchor).isActive = true
        
        imageview.addGestureRecognizer(pinchgesture)
        pinchgesture.addTarget(self, action: #selector(pinchaction))
        
    }
    
    @objc func pinchaction(){
        guard let gestureview = pinchgesture.view else {
            return
        }
        gestureview.transform = gestureview.transform.scaledBy(x: pinchgesture.scale, y: pinchgesture.scale)
        pinchgesture.scale = 1
    }


}

