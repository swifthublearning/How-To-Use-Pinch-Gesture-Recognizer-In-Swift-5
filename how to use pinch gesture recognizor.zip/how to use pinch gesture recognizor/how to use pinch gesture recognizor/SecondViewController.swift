//
//  SecondViewController.swift
//  how to use pinch gesture recognizor
//
//  Created by Supine Hub Technologies Pvt. Ltd. on 17/03/20.
//  Copyright © 2020 Supine Hub Technologies Pvt. Ltd. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    @IBOutlet var pinchgesture: UIPinchGestureRecognizer!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func pinchgestureaction(_ sender: Any) {
        guard let gestureview = pinchgesture.view else {
            return
        }
        gestureview.transform = gestureview.transform.scaledBy(x: pinchgesture.scale, y: pinchgesture.scale)
        pinchgesture.scale = 1
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
